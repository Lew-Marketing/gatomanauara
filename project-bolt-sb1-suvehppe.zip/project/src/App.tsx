import React from 'react';
import { SalesPage } from './components/SalesPage';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <SalesPage />
    </div>
  );
}

export default App;