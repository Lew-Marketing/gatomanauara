import React from 'react';
import { BookOpen } from 'lucide-react';
import { SOLUTION_POINTS, DIFFERENCE_POINTS } from '../constants/content';

export const Solution: React.FC = () => {
  return (
    <div className="w-full bg-purple-50 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-8">
          <BookOpen className="text-purple-600 w-8 h-8 mr-3" />
          <h3 className="text-2xl md:text-3xl font-bold text-gray-800">
            O que é o e-book "Linguagem Felina Descodificada"?
          </h3>
        </div>
        
        <p className="text-xl text-center text-gray-700 mb-12">
          É um guia prático, direto e emocional, feito para tutores que querem ir além do básico.
        </p>
        
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white rounded-lg shadow-md p-8">
            <h4 className="text-xl font-bold text-gray-800 mb-6">O e-book ensina:</h4>
            <div className="space-y-4">
              {SOLUTION_POINTS.map((point, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                    <svg className="w-4 h-4 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-gray-700">{point.text}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-amber-50 rounded-lg shadow-md p-8">
            <h4 className="text-xl font-bold text-gray-800 mb-6">Por que é diferente?</h4>
            <div className="space-y-4">
              {DIFFERENCE_POINTS.map((point, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center mr-3">
                    <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  </div>
                  <p className="text-gray-700">{point.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="flex justify-center">
          <CTAButton />
        </div>
      </div>
    </div>
  );
};

import { CTAButton } from './CTAButton';