import React from 'react';
import { Hero } from './Hero';
import { EbookMockup } from './EbookMockup';
import { PainPoints } from './PainPoints';
import { Benefits } from './Benefits';
import { Solution } from './Solution';
import { ProductSample } from './ProductSample';
import { Testimonials } from './Testimonials';
import { Offer } from './Offer';
import { FAQ } from './FAQ';
import { Footer } from './Footer';

export const SalesPage: React.FC = () => {
  React.useEffect(() => {
    // Update the page title
    document.title = "Linguagem Felina Descodificada | Gatomanauara Catshop";
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <div className="w-full">
      <Hero />
      <EbookMockup />
      <PainPoints />
      <Benefits />
      <Solution />
      <ProductSample />
      <Testimonials />
      <div id="offer-section">
        <Offer />
      </div>
      <FAQ />
      <Footer />
    </div>
  );
};