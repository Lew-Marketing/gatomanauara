import React from 'react';
import { EBOOK_PRICE } from '../constants/content';

interface CTAButtonProps {
  large?: boolean;
  showPrice?: boolean;
}

export const CTAButton: React.FC<CTAButtonProps> = ({ large = false, showPrice = false }) => {
  const scrollToOffer = () => {
    const offerElement = document.getElementById('offer-section');
    if (offerElement) {
      offerElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <button
      onClick={scrollToOffer}
      className={`
        group w-full 
        ${large ? 'py-3 sm:py-4 text-base sm:text-xl' : 'py-2.5 sm:py-3 text-base sm:text-lg'}
        bg-gato-orange hover:bg-gato-orange/90 active:bg-gato-orange/80
        text-white font-bold 
        rounded-lg sm:rounded-xl shadow-lg transition-all duration-300 
        transform hover:scale-102 active:scale-98 hover:shadow-xl
        flex items-center justify-center gap-2 sm:gap-3
        relative overflow-hidden
        touch-manipulation
      `}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-gato-yellow/20 to-transparent transform -skew-x-12 group-hover:skew-x-12 transition-transform duration-700"></div>
      <span className="relative">QUERO ENTENDER MEU GATO AGORA</span>
      {showPrice && (
        <span className="relative bg-white text-gato-orange text-xs sm:text-sm px-2 sm:px-3 py-0.5 sm:py-1 rounded-full shadow-sm">
          {EBOOK_PRICE}
        </span>
      )}
    </button>
  );
};