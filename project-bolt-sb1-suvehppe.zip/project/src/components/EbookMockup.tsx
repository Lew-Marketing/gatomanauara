import React from 'react';
import { CTAButton } from './CTAButton';

export const EbookMockup: React.FC = () => {
  return (
    <div className="w-full bg-gato-green/95 text-white py-8 md:py-16 px-4">
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center gap-8 md:gap-12">
        {/* Mobile-first book mockup */}
        <div className="w-full max-w-sm mx-auto md:max-w-none md:w-1/2">
          <div className="relative group perspective-1000">
            {/* Ambient light effect */}
            <div className="absolute -inset-3 md:-inset-4 bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 opacity-20 blur-lg group-hover:opacity-30 transition-opacity duration-700"></div>
            
            {/* Book Container */}
            <div className="relative preserve-3d group-hover:rotate-y-10 transition-transform duration-700 ease-out">
              {/* Book Cover */}
              <div className="relative bg-gradient-to-br from-amber-800 to-amber-950 rounded-lg shadow-2xl overflow-hidden">
                {/* Cover texture */}
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIj48cmVjdCB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9Im5vbmUiLz48cGF0aCBkPSJNMCAwaDQwdjQwSDB6IiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIwLjUiLz48L3N2Zz4=')] opacity-10"></div>
                
                <div className="p-4 md:p-6">
                  {/* Book Title */}
                  <div className="text-center mb-4 md:mb-6">
                    <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white drop-shadow-lg leading-tight">
                      Linguagem Felina Descodificada
                    </h3>
                  </div>
                  
                  {/* Cover Image */}
                  <div className="relative h-48 sm:h-56 md:h-64 rounded-lg overflow-hidden shadow-xl mb-4">
                    <div className="absolute inset-0 bg-black/20 z-10"></div>
                    <img 
                      src="https://images.pexels.com/photos/1440387/pexels-photo-1440387.jpeg" 
                      alt="Gato próximo ao computador"
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                    />
                    {/* Texture overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent mix-blend-overlay"></div>
                  </div>

                  {/* Mobile-only CTA */}
                  <div className="block md:hidden">
                    <CTAButton />
                  </div>
                </div>
              </div>
              
              {/* Book Spine */}
              <div className="absolute left-0 top-0 w-4 md:w-6 h-full bg-gradient-to-r from-amber-800 to-amber-900 transform -translate-x-4 md:-translate-x-6 rotate-y-90 origin-right rounded-l-sm">
                <div className="w-full h-full relative overflow-hidden">
                  {/* Spine texture */}
                  <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIj48cmVjdCB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9Im5vbmUiLz48cGF0aCBkPSJNMCAwaDQwdjQwSDB6IiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIwLjUiLz48L3N2Zz4=')] opacity-10"></div>
                  {/* Inner shadow */}
                  <div className="absolute inset-0 shadow-inner"></div>
                </div>
              </div>
              
              {/* Book Pages */}
              <div className="absolute right-0 top-0 bottom-0 w-2 transform translate-x-2">
                {/* Individual pages */}
                {[...Array(20)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute inset-0 bg-white/90 transform"
                    style={{
                      transformOrigin: 'left',
                      transform: `translateZ(${-i * 0.1}px)`,
                    }}
                  ></div>
                ))}
                {/* Pages shadow */}
                <div className="absolute inset-0 bg-gradient-to-r from-black/10 to-transparent"></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Content section */}
        <div className="w-full md:w-1/2 text-center md:text-left">
          <h3 className="text-lg sm:text-xl md:text-2xl font-semibold mb-4 md:mb-6 leading-relaxed">
            Criado por quem convive com centenas de gatos todos os dias, este e-book revela os erros invisíveis que afastam seu felino — e o passo a passo para reconstruir uma conexão verdadeira.
          </h3>
          <p className="text-white/80 mb-6 md:mb-8 text-base sm:text-lg">
            O e-book foi desenvolvido após anos de observação e análise do comportamento felino. Reunimos as técnicas mais eficientes para fortalecer o vínculo entre tutores e seus gatos.
          </p>
          {/* Desktop-only CTA */}
          <div className="hidden md:flex justify-start">
            <CTAButton />
          </div>
        </div>
      </div>
    </div>
  );
};