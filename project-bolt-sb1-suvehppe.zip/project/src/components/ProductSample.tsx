import React from 'react';
import { BookOpen } from 'lucide-react';
import { CONTENT_POINTS } from '../constants/content';

export const ProductSample: React.FC = () => {
  return (
    <div className="w-full bg-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-10">
          <BookOpen className="text-amber-600 w-8 h-8 mr-3" />
          <h3 className="text-2xl md:text-3xl font-bold text-gray-800">
            Dentro do e-book você encontra:
          </h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-100 to-purple-100 transform rotate-1 rounded-lg"></div>
            <div className="relative bg-white rounded-lg shadow-lg p-8 z-10">
              <div className="space-y-4">
                {CONTENT_POINTS.map((point, index) => (
                  <div key={index} className="flex items-start">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center mr-3 mt-1">
                      <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-gray-700">{point}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h4 className="font-bold text-lg text-gray-800 mb-3">Exemplo: Sinais de Desconforto</h4>
              <p className="text-gray-600 mb-4">
                Quando seu gato se esconde após sua aproximação, não significa necessariamente que ele não gosta de você.
              </p>
              <div className="flex space-x-4">
                <div className="flex-1 bg-red-50 p-3 rounded-md">
                  <p className="font-medium text-red-700 mb-1">O que o tutor pensa:</p>
                  <p className="text-red-600 text-sm">"Meu gato não gosta de mim"</p>
                </div>
                <div className="flex-1 bg-green-50 p-3 rounded-md">
                  <p className="font-medium text-green-700 mb-1">O que o gato sente:</p>
                  <p className="text-green-600 text-sm">"Preciso de mais tempo para me sentir seguro"</p>
                </div>
              </div>
            </div>
            
            <div className="bg-purple-50 rounded-lg p-6">
              <h4 className="font-bold text-lg text-gray-800 mb-3">No e-book você aprende:</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Como identificar quando seu gato precisa de espaço</li>
                <li>O tempo certo para oferecer interação</li>
                <li>Sinais sutis que indicam abertura para aproximação</li>
                <li>Técnicas de dessensibilização para gatos mais arredios</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <p className="text-xl text-gray-700 mb-6">
            Transforme a relação com seu gato e crie uma conexão duradoura.
          </p>
          <CTAButton />
        </div>
      </div>
    </div>
  );
};

import { CTAButton } from './CTAButton';