import React, { useState } from 'react';
import { HelpCircle } from 'lucide-react';
import { FAQS } from '../constants/content';

export const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  
  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };
  
  return (
    <div className="w-full bg-white py-16 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-center mb-10">
          <HelpCircle className="text-amber-600 w-8 h-8 mr-3" />
          <h3 className="text-2xl md:text-3xl font-bold text-gray-800">
            Perguntas Frequentes
          </h3>
        </div>
        
        <div className="space-y-4 mb-12">
          {FAQS.map((faq, index) => (
            <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
              <button
                className="w-full flex items-center justify-between p-4 text-left bg-gray-50 hover:bg-gray-100 transition-colors"
                onClick={() => toggleFAQ(index)}
              >
                <span className="font-medium text-gray-800">{faq.question}</span>
                <svg
                  className={`w-5 h-5 text-gray-500 transform transition-transform ${openIndex === index ? 'rotate-180' : ''}`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${
                  openIndex === index ? 'max-h-40' : 'max-h-0'
                }`}
              >
                <div className="p-4 bg-white border-t border-gray-200">
                  <p className="text-gray-700">{faq.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <p className="text-lg text-gray-700 mb-6">
            Ainda tem dúvidas? Entre em contato conosco pelo Instagram <a href="https://instagram.com/gatomanauara" className="text-amber-600 hover:underline" target="_blank" rel="noopener noreferrer">@gatomanauara</a>.
          </p>
          <CTAButton />
        </div>
      </div>
    </div>
  );
};

import { CTAButton } from './CTAButton';