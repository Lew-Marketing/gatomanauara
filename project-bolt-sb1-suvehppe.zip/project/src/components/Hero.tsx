import React from 'react';
import { Cat } from 'lucide-react';
import { CTAButton } from './CTAButton';

export const Hero: React.FC = () => {
  return (
    <div className="w-full bg-gradient-to-b from-gato-green/5 to-gato-yellow/5 py-8 px-4 sm:py-12 md:py-16">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col items-center text-center">
          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-800 mb-4 sm:mb-6 leading-tight max-w-4xl">
            Você sente que seu gato está tentando te dizer algo...{' '}
            <span className="text-gato-orange">mas você não entende?</span>
          </h1>
          
          <h2 className="text-lg sm:text-xl md:text-2xl text-gray-600 max-w-3xl mb-8 sm:mb-10 leading-relaxed px-2">
            Descubra os 7 sinais silenciosos de que seu gato está emocionalmente desequilibrado — e como reconquistar o vínculo sem castigos, brinquedos caros ou trocar a ração.
          </h2>
          
          <div className="w-full max-w-md mb-8 sm:mb-12 relative px-4">
            <div className="absolute -inset-1 bg-gradient-to-r from-gato-yellow via-gato-orange to-gato-green opacity-20 blur"></div>
            <div className="relative">
              <CTAButton />
            </div>
          </div>
          
          <div className="w-12 h-12 sm:w-16 sm:h-16 flex items-center justify-center rounded-full bg-gradient-to-br from-gato-green/20 to-gato-yellow/20 text-gato-green animate-float">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
};