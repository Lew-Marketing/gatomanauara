import React from 'react';
import { Package, ShieldCheck } from 'lucide-react';
import { BONUSES, EBOOK_PRICE } from '../constants/content';
import { CTAButton } from './CTAButton';

export const Offer: React.FC = () => {
  return (
    <div className="w-full bg-purple-50 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-10">
          <Package className="text-purple-600 w-8 h-8 mr-3" />
          <h3 className="text-2xl md:text-3xl font-bold text-gray-800">
            O que está incluído na oferta
          </h3>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="bg-amber-600 p-4 text-white text-center">
              <h4 className="text-xl font-bold">E-book Completo</h4>
            </div>
            <div className="p-6">
              <p className="text-gray-700 mb-4">
                <span className="font-bold">Linguagem Felina Descodificada</span> - Um guia completo com mais de 60 páginas práticas sobre como entender e se comunicar com seu gato.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-600">PDF de alta qualidade</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-600">Técnicas testadas e aprovadas</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-600">Ilustrações explicativas</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-600">Linguagem simples e direta</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div>
            <h4 className="text-xl font-bold text-gray-800 mb-4">Bônus Especiais</h4>
            <div className="space-y-4">
              {BONUSES.map((bonus, index) => (
                <div key={index} className="bg-white rounded-lg p-4 shadow-md border-l-4 border-amber-500">
                  <h5 className="font-bold text-gray-800 mb-1">{bonus.title}</h5>
                  <p className="text-gray-600 text-sm">{bonus.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg p-8 text-center">
          <div className="flex items-center justify-center mb-6">
            <ShieldCheck className="text-green-600 w-8 h-8 mr-2" />
            <h4 className="text-xl font-bold text-gray-800">7 Dias de Garantia Incondicional</h4>
          </div>
          
          <p className="text-gray-700 mb-8">
            Se você não sentir que entendeu mais seu gato e melhorou a convivência, devolvemos 100% do seu dinheiro. Sem perguntas.
          </p>
          
          <div className="mb-6">
            <p className="text-gray-500 text-sm line-through">De R$ 47</p>
            <p className="text-3xl font-bold text-gray-800 mb-1">Por apenas {EBOOK_PRICE}</p>
            <p className="text-gray-600">Pagamento único, sem mensalidades</p>
          </div>
          
          <CTAButton large showPrice />
          
          <p className="text-gray-500 text-sm mt-4">
            Entrega imediata via e-mail após o pagamento
          </p>
        </div>
      </div>
    </div>
  );
};