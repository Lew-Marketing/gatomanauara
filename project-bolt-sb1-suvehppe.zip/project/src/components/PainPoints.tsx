import React from 'react';
import { PAIN_POINTS } from '../constants/content';

export const PainPoints: React.FC = () => {
  return (
    <div className="w-full bg-gradient-to-b from-gato-yellow/5 to-gato-orange/5 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-xl p-8 md:p-12 transform -translate-y-16">
          <h3 className="text-2xl font-bold text-gato-green mb-8 text-center">Isso parece familiar?</h3>
          
          <div className="space-y-6 mb-8">
            {PAIN_POINTS.map((point, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gato-orange/10 flex items-center justify-center mr-4">
                  <svg className="w-6 h-6 text-gato-orange" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <p className="text-lg text-gray-700">{point}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-gato-yellow/10 border-l-4 border-gato-yellow p-4 mb-8">
            <p className="text-lg font-medium text-gray-700">Você não está sozinho.</p>
            <p className="text-gray-600 mt-2">
              A verdade é que a maioria dos tutores não entende o que o gato está dizendo — e isso afasta vocês sem perceber.
            </p>
          </div>
          
          <p className="text-xl text-center text-gray-700 font-medium">
            Este guia foi feito por quem vive com gatos todos os dias — para que você finalmente entenda o que o seu está tentando te dizer.
          </p>
        </div>
        
        <div className="mt-8 text-center">
          <h3 className="text-3xl font-bold text-gato-green mb-2">E se você pudesse compreender seu gato?</h3>
          <p className="text-xl text-gray-600 mb-8">
            Imagine resolver os conflitos, entender suas necessidades e fortalecer o vínculo com ele.
          </p>
        </div>
      </div>
    </div>
  );
};