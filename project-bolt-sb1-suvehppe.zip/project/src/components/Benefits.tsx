import React from 'react';
import { BENEFITS } from '../constants/content';

export const Benefits: React.FC = () => {
  return (
    <div className="w-full bg-gato-green/95 text-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <h3 className="text-2xl md:text-3xl font-bold mb-10 text-center">
          Com este e-book, você vai:
        </h3>
        
        <div className="grid gap-6 md:grid-cols-2">
          {BENEFITS.map((benefit, index) => (
            <div 
              key={index} 
              className="bg-white/10 backdrop-blur-sm rounded-lg p-6 transform transition-all duration-300 hover:bg-white/20"
            >
              <div className="flex items-start">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gato-yellow/20 flex items-center justify-center mr-4">
                  <svg className="w-6 h-6 text-gato-yellow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="text-lg text-white/90">{benefit.text}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-xl text-white/90 mb-6">
            Tudo isso por um valor menor do que um saco de ração premium!
          </p>
          <CTAButton />
        </div>
      </div>
    </div>
  );
};

import { CTAButton } from './CTAButton';