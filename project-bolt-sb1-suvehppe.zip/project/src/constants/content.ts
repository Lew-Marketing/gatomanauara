import { Benefit, Bonus, FAQ, SolutionPoint, Testimonial } from '../types';

export const BENEFITS: Benefit[] = [
  { text: 'Identificar os 7 sinais silenciosos de desequilíbrio emocional felino.' },
  { text: 'Entender o que cada postura, olhar e comportamento realmente quer dizer.' },
  { text: 'Reconstruir a confiança do seu gato com atitudes simples e eficazes.' },
  { text: 'Evitar erros comuns que causam afastamento e estresse no gato.' },
  { text: 'Criar um vínculo mais profundo, calmo e respeitoso com seu felino.' },
];

export const PAIN_POINTS = [
  'Seu gato vive te evitando, mesmo você tentando dar carinho?',
  'Você sente que está errando, mas não sabe onde?',
  'Já tentou brinquedos, petiscos, colos — mas nada parece funcionar?',
];

export const SOLUTION_POINTS: SolutionPoint[] = [
  { text: 'Explica como gatos expressam emoções sem falar.' },
  { text: 'Ensina como agir quando o gato se fecha, se esconde ou evita contato.' },
  { text: 'Repleto de exemplos reais, ilustrações e orientações que funcionam.' },
];

export const DIFFERENCE_POINTS: SolutionPoint[] = [
  { text: 'Não é sobre "adestrar" o gato. É sobre entender e respeitar a linguagem dele.' },
  { text: 'Criado por uma equipe que lida com gatos todos os dias, e conhece os detalhes que ninguém te conta.' },
  { text: 'Vai direto ao ponto — sem enrolação, técnica ou termos difíceis.' },
];

export const CONTENT_POINTS = [
  'Lista com os 7 sinais invisíveis que indicam desconexão emocional.',
  'Guia prático de como reagir a cada comportamento.',
  'Quadro comparativo: o que o tutor pensa vs. o que o gato realmente sente.',
  'Ferramentas para criar uma rotina segura e emocionalmente saudável.',
];

export const TESTIMONIALS: Testimonial[] = [
  {
    quote: 'Eu achava que meu gato era arisco. Descobri que ele só estava se sentindo inseguro. Mudei pequenas atitudes e hoje ele dorme comigo toda noite.',
    author: 'Vanessa A.',
    location: 'Recife/PE',
  },
  {
    quote: 'Esse e-book me mostrou que eu estava interpretando tudo errado. Meu gato não era frio, ele só estava pedindo espaço. Nossa conexão mudou completamente.',
    author: 'Ricardo L.',
    location: 'Manaus/AM',
  },
];

export const BONUSES: Bonus[] = [
  {
    title: 'Checklist "10 Erros Que Afastam Seu Gato — e Como Corrigir"',
    description: 'Um guia prático para evitar os erros mais comuns que prejudicam sua relação.',
  },
  {
    title: 'Mini-guia "Rituais Diários para Fortalecer o Vínculo Felino"',
    description: 'Atividades simples para construir confiança diariamente.',
  },
  {
    title: 'Playlist de áudios que acalmam gatos',
    description: 'Sons testados no Catshop que promovem relaxamento e bem-estar.',
  },
];

export const FAQS: FAQ[] = [
  {
    question: 'É só para gatos filhotes?',
    answer: 'Não. Funciona para gatos de todas as idades.',
  },
  {
    question: 'Preciso ter experiência com gatos?',
    answer: 'Não. O conteúdo é acessível e direto.',
  },
  {
    question: 'Funciona mesmo se meu gato for "difícil"?',
    answer: 'Sim — principalmente nesses casos.',
  },
  {
    question: 'Quanto tempo leva para ver resultados?',
    answer: 'Muitos tutores relatam mudanças no comportamento do gato em apenas alguns dias após aplicar as técnicas.',
  },
  {
    question: 'O e-book é enviado por e-mail?',
    answer: 'Sim. Logo após a compra, você receberá o link para download no seu e-mail.',
  },
];

export const EBOOK_PRICE = 'R$ 27';