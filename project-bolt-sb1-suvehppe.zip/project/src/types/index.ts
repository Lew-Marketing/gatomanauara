export interface Testimonial {
  quote: string;
  author: string;
  location: string;
}

export interface FAQ {
  question: string;
  answer: string;
}

export interface Benefit {
  text: string;
}

export interface SolutionPoint {
  text: string;
}

export interface Bonus {
  title: string;
  description: string;
}