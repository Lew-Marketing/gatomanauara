/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'gato': {
          'green': '#2A5A27',
          'yellow': '#FFD700',
          'orange': '#FF8C00',
        }
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '2rem',
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        }
      },
      scale: {
        '102': '1.02',
        '98': '0.98',
      },
      rotate: {
        'y-10': 'rotateY(10deg)',
        'y-90': 'rotateY(90deg)',
      },
      transformOrigin: {
        'right': 'right',
      },
      perspective: {
        '1000': '1000px',
      },
      transform: {
        'preserve-3d': 'preserve-3d',
      },
    },
  },
  plugins: [],
};